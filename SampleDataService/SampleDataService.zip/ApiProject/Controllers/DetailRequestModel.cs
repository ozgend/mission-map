﻿namespace ApiProject.Controllers
{
    public class DetailRequestModel
    {
        public int CustomerId { get; set; }
    }
}